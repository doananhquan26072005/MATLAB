function [] = baitap1()
    A = [2 4 5/2
        -3/4 2 1/4
        1/4 1/2 2];

    B = [1 -1/2 3/4
        3/2 1/2 -2
        1/4 1 1/2];

    disp("A^(-1) * B^(-1) = ");
    disp(A^(-1) * B^(-1));
    disp("(A * B) ^ (-1) = ");
    disp((A * B) ^ (-1));
    disp("(B * A) ^ (-1) = ");
    disp((B * A) ^ (-1));
    
    C = A^(-1);
    D = A;

    for i = 1 : 3
        for j = 1 : 3
            if (i < j)
                x = C(i , j);
                C(i , j) = C(j , i);
                C(j , i) = x;

                x = D(i , j);
                D(i , j) = D(j , i);
                D(j , i) = x;
            end
        end
    end

    disp("(A ^ (-1)) ^ T = ");
    disp(C);
    disp("(A ^ T) ^ (-1) = ");
    disp(D^(-1));
end