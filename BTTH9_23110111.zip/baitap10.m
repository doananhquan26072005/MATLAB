function [] = baitap10()
    A = randi([-20 , 20], [100 , 100]);
    disp(A);
    while (det(A) == 0)
        A = randi([-20 , 20], [5 , 5]);
        disp(A);
    end
    
    C = inv(A);
    I = eye(100);
    for i = 101 : 200
        A(:,i) = I(:,i - 100);
    end
    
    B = rref(A);
    for i = 1 : 100
        D(:,i) = B(:,i + 100);
    end
    disp("A ^ (-1) theo bien doi so cap dong la ");
    disp(D);

    disp("A ^ (-1) theo inv ");
    disp(C);
end