function [] = baitap2_2()
    A = [3 3 3
        1 1 4
        2 -5 4];

    B = [2
        -2
        3];

    X = A^(-1) * B;
    
    disp("Nghiem giai he AX = B")
    disp("x = ");
    disp(X(1 , 1));
    disp("y = ");
    disp(X(2 , 1));
    disp("z = ");
    disp(X(3 , 1));

    disp("Nghiem rref");
    C = [3 3 3 2
        1 1 4 -2
        2 -5 4 3];
    C = rref(C);
    
    disp("x = ");
    disp(C(1 , 4));
    disp("y = ");
    disp(C(2 , 4));
    disp("z = ");
    disp(C(3 , 4));
end