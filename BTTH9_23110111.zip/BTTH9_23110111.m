%Ho va ten: Doan Anh Quan
%MSSV: 23110111
clear
close all
format long
%  baitap1();
%  baitap2.1();
%  baitap2.2();
%  baitap3a();
%  baitap3b();
%  baitap4();
%  baitap5();
%  baitap6();
%  baitap7();
%  baitap8();
%  baitap9();
%  baitap10();
%  baitap11();