function [] = baitap6()
    A = [1 2 3 4 1 0 0 0
        2 5 4 7 0 1 0 0
        3 7 8 12 0 0 1 0
        4 8 14 19 0 0 0 1];
    A = rref(A);
    disp(A);
end