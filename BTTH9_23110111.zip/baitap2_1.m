function [] = baitap2_1()
    A = [1 -2 3 9
        -1 3 0 -4
        2 -5 5 17];
    A = rref(A);
    disp("x = ");
    disp(A(1 , 4));
    disp("y = ");
    disp(A(2 , 4));
    disp("z = ");
    disp(A(3 , 4));
end