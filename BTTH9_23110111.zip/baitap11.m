function [] = baitap11()
    A = input("Nhap ma tran A = ");
    B = input("Nhap ma tran B = ");
    X = He_PT(A , B);
    disp("Nghiem cua AX = B la ");
    disp(X)
end

function [X] = He_PT(A , B)
    X = B;
    for i = 1 : size(A , 1)
        C = A;
        C(:,i) = B;
        X(i , 1) = det(C) / det(A);
    end
end