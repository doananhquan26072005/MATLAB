function [] = baitap9()
    subplot(2,3,1);
    u = linspace(0 , 4);
    v = linspace(0 , 2 * pi);
    [U , V] = meshgrid(u , v);
    x = U .* cos(V);
    y = U .* sin(V);
    z = U.^2 + 1;
    plot3(x , y , z);
    title('Do thi ham so a');

    subplot(2,3,2);
    u = linspace(-1 , 1);
    v = linspace(0 , 2 * pi);
    [U , V] = meshgrid(u , v);
    x = sqrt(1 + 4 .* V .^2) .* cos(U);
    y = V;
    z = sqrt(1 + 4 .* V .^2) .* sin(U);
    plot3(x , y , z);
    title('Do thi ham so b');

    subplot(2,3,3);
    u = linspace(0 , 4 * pi);
    v = linspace(0 , 2 * pi);
    [U , V] = meshgrid(u , v);
    x = (2 + sin(U)) .* cos(V);
    y = U;
    z = (2 + sin(U)) .* sin(V);
    plot3(x , y , z);
    title('Do thi ham so c');

    subplot(2,3,4);
    u = linspace(0 , 2 * pi);
    v = linspace(0 , 4 * pi);
    [U , V] = meshgrid(u , v);
    x = cos(U) ./ 4 + cos(V);
    y = sin(U) ./ 4 + sin(V);
    z = V;
    plot3(x , y , z);
    title('Do thi ham so d');

    subplot(2,3,5);
    u = linspace(0 , 4 * pi);
    v = linspace(0 , 2 * pi);
    [U , V] = meshgrid(u , v);
    x = cos(U);
    y = sin(U);
    z = (U + V) ./ 4;
    plot3(x , y , z);
    title('Do thi ham so e');

    subplot(2,3,6);
    u = linspace(0 , 2 * pi);
    v = linspace(0 , 4 * pi);
    [U , V] = meshgrid(u , v);
    x = U .* cos(V);
    y = U .* sin(V);
    z = U .* V;
    plot3(x , y , z);
    title('Do thi ham so f');
end
