function [] = baitap8()
    A = input("Nhap ma tran A = ");
    B = input("Nhap ma tran B = ");
    x = B;

    for i = 1 : size(A , 1)
        C = A;
        C(:,i) = B;
        x(i , 1) = det(C) / det(A);
    end

    disp("Nghiem cua AX = B la ");
    disp(x);
end