function [] = baitap3a()
    x = linspace(-2 * pi , 2 * pi);
    f = x .* sin(x);
    g = x .* cos(x);
    
    x_giao = [-7*pi/4 -3*pi/4 0 pi/4 5*pi/4];
    plot(x , f ,'r-', x , g , 'b-');
    hold on;
    for i = 1 : 5
        plot(x_giao(i) , x_giao(i) * sin(x_giao(i)) , 'k*');
    end
end