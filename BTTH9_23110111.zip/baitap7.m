function [] = baitap7()
    A = randi([-20 , 20], [5 , 5]);
    disp(A);
    while (det(A) == 0)
        A = randi([-20 , 20], [5 , 5]);
        disp(A);
    end
    
    C = inv(A);
    A(:,[6 7 8 9 10]) = eye(5);
    
    B = rref(A);
    B = B(: , [6 7 8 9 10]);
    disp("A ^ (-1) theo bien doi so cap dong la ");
    disp(B);

    disp("A ^ (-1) theo inv ");
    disp(C);
end