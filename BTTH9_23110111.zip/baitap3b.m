function [] = baitap3b()
    t = linspace(-20 , 20);
    x = 5 * (cos(t) + t .* sin(t));
    y = 5 * (sin(t) - t .* cos(t));
    z = x;
    line(x , z);
    hold on;
    plot(x , y);
end