function [] = baitap5()
    A = [3 3 4
        1 1 4
        2 -5 4];
    B = [2
        -2
        3];
    x = zeros(3 , 1);

    A1 = A;
    A1(:,1) = B;
    x(1 , 1) = det(A1) / det(A);

    A2 = A;
    A2(:,2) = B;
    x(2 , 1) = det(A2) / det(A);

    A3 = A;
    A3(:,3) = B;
    x(3 , 1) = det(A3) / det(A);

    disp(x);
end