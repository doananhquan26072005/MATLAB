function [] = baitap4c()
    A = [1 3];
    plot(A(1) , A(2) , 'ro');
    hold on;
    text(A(1), A(2), 'A' , 'VerticalAlignment', 'bottom');

    B = [-3 5];
    plot(B(1) , B(2) , 'bsquare');
    hold on;
    text(B(1), B(2), 'B' , 'VerticalAlignment', 'bottom');

    C = [2 -4];
    plot(C(1) , C(2) , 'm<');
    hold on;
    text(C(1), C(2), 'C' , 'VerticalAlignment', 'bottom');

    D = [-1 -3];
    plot(D(1) , D(2) , 'y>');
    hold on;
    text(D(1), D(2), 'D' , 'VerticalAlignment', 'bottom');

    O = [0 0];
    plot(O(1) , O(2) , 'kdiamond');
    hold on;
    text(O(1), O(2), 'O' , 'VerticalAlignment', 'bottom' , 'HorizontalAlignment', 'right');

    plot([A(1) , B(1)] , [A(2) , B(2)] , "LineWidth", 2);
    hold on;

    plot([B(1) , C(1)] , [B(2) , C(2)] , "LineWidth", 2);
    hold on;

    plot([A(1) , C(1)] , [A(2) , C(2)] , "LineWidth", 2);
    hold on;

    plot([B(1) , D(1)] , [B(2) , D(2)] , "LineWidth", 2);
    hold on;

    plot([D(1) , A(1)] , [D(2) , A(2)] , "LineWidth", 2);
    hold on;

    plot([D(1) , C(1)] , [D(2) , C(2)] , "LineWidth", 2);
    hold on;

    plot([D(1) , O(1)] , [D(2) , O(2)] , "LineWidth", 2);
    hold on;

    axis([-5 3 -5 6]);
    grid on;
end