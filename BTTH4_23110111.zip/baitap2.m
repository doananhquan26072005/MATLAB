function [] = baitap2()
    x = input("Nhap vecto x = ");
    n = input("Nhap n = ");
    for i = 1 : length(x)
        for j = 1 : n
            y((i - 1) * n + j) = x(i);
        end
    end
    disp(y);
end