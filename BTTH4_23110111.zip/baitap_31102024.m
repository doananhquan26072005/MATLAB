%Doan_Anh_Quan
%MSSV 23110111
clc
clear
close all
format long
%  baitap1;
%  baitap2;
%  baitap3;
%  baitap4;
%  baitap5;
%  baitap6;
%  baitap7;
%  baitap8;
%  baitap9;