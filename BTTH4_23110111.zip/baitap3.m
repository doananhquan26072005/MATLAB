function [] = baitap3()
    A = input("Nhap ma tran A = ");
    B = input("Nhap ma tran B = ");
    
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            C(i , j) = A(i , j) + B(i , j);
        end
    end

    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            D(i , j) = A(i , j) - B(i , j);
        end
    end

    for i = 1 : size(A , 1)
        for j = 1 : size(B , 2)
            E(i , j) = 0;
            F(i , j) = 0;
        end
    end

    for i = 1 : size(A , 1)
        for j = 1 : size(B , 2)
            for k = 1 : size(A , 2)
                E(i , j) = E(i , j) + A(i , k) * B(k , j);
            end
        end
    end

    for i = 1 : size(B , 1)
        for j = 1 : size(A , 2)
            for k = 1 : size(B , 2)
                F(i , j) = F(i , j) + B(i , k) * A(k , j);
            end
        end
    end

    disp("A + B = ");
    disp(C);
    disp("A - B = ");
    disp(D);
    disp("AB = ");
    disp(E);
    disp("BA = ");
    disp(F);
end