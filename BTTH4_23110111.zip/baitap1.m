function [] = baitap1()
    A = input("Nhap ma tran A = ");
    A = sortrows(A,2,'descend');
    disp(A);
end