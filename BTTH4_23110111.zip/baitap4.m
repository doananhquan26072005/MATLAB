function [] = baitap4()
    A = input("Nhap ma tran A = ");
    if(size(A , 1) ~= size(A , 2) || det(A) == 0)
        disp("A khong phai ma tran unita!");
    end
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
           AT(i , j) = A(j , i); 
        end
    end
    if(A^(-1) ~= AT)
        disp("A khong phai ma tran unita!");
    else
        disp("A la ma tran unita!");
    end
end