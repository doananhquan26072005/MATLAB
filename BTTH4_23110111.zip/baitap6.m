function [] = baitap6()
    A = input("Nhap ma tran A = ");
    if(size(A , 1) ~= size(A , 2))
        disp("A khong phai ma tran doi xung!");
    end
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
           AT(i , j) = A(j , i); 
        end
    end
    if(A ~= AT)
        disp("A khong phai ma tran doi xung!");
    else
        disp("A la ma tran doi xung!");
    end
end