function [] = baitap5()
    A = [1 2 3
        2 1 5
        4 6 4
        2 3 2];
    A1 = A(1 , :);
    A2 = A(2 , :);
    A3 = A(3 , :);
    A4 = A(4 , :);
    A = [A3 
        A4
        A1
        A2];
    disp(A);
end