function [] = baitap3()
    u = linspace(0, 1);
    v = linspace(0, 2*pi);
    [U, V] = meshgrid(u, v);
    X = (1-U) .* (3 + cos(V)) .* cos(5*pi*U);
    Y = (1-U) .* (3 + cos(V)) .* sin(5*pi*U);
    Z = 2*U + (1-U) .* sin(V);
    surf(X, Y, Z);
end