function [] = baitap8()
    x = linspace(-3 , 0);
    y1 = sqrt(x.^2 .* (x + 3));
    y2 = -sqrt(x.^2 .* (x + 3));
    plot(x , y1 , x , y2);

    syms x y;
    y1 = sqrt(x^2 * (x + 3));
    y2 = -sqrt(x^2 * (x + 3));
    V = int(int(1 , y , y2 , y1) , x , -3 , 0);
    disp(V);
end