function [] = baitap9c()
    syms t;
    T = solve(3*t^2 - 3 == 0 , t);
    disp(T(1));

    a = @(t) 6*t;

    disp("Gia toc khi van toc = 0 co the la ");
    disp(a(T(1)));
    disp("Gia toc khi van toc = 0 co the la ");
    disp(a(T(2)));
end