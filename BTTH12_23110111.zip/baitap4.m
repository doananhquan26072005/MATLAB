function [] = baitap4()
    n = linspace(-10 , 10);
    f = (-1) .^n .* (n + 1) ./ n;
    subplot(1, 2 , 1);
    plot(n , f);
    title("Do thi cau a");

    f = sin(n) ./ sqrt(n);
    subplot(1, 2 , 2);
    plot(n , f);
    title("Do thi cau b");
end