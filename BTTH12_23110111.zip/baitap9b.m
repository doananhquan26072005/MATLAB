function [] = baitap9b()
    a = @(t) 6*t;
    disp("Gia toc sau 2 giay la ");
    disp(a(2));
end