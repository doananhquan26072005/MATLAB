%Ho va ten: Doan Anh Quan
%MSSV: 23110111
clear
close all
format long
%  baitap1();
%  baitap2();
%  baitap3();
%  baitap4();
%  baitap5();
%  baitap6();
%  baitap7();
%  baitap8();
%  baitap9a();
%  baitap9b();
%  baitap9c();
%  baitap10();