function [] = baitap6()
    A = randi([0 , 100], [1 , 100000]);
    tic;
    B = A(mod(A , 3) == 0);
    disp("Thoi gian lam cach 1 la ");
    toc;
    tic;
    dem = 0;
    for i = 1 : 100000
        dem = dem + 1;
        C(dem) = A(i);
    end
    disp("Thoi gian lam cach 2 la ");
    toc;
end