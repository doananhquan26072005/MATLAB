function [] = baitap7()
    F = input("Nhap do F = ");
    while(isempty(F) == 0)
        disp("Do C =");
        disp(5 / 9 * (F - 32));
        F = input("Nhap do F = ");
    end
end