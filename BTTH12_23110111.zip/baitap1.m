function [] = baitap1()
    syms x;
    P = {};
    P{1} = 1;
    P{2} = x;
    for i = 3 : 6
        n = i - 1;
        P{i} = (2 * n - 1) * P{n} - (n - 1) * P{n - 1};
        P{i} = P{i} / n;
    end
    for i = 1 : 6
        disp(P{i});
    end
end
