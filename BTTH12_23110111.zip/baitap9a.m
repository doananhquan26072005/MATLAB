function [] = baitap9a()
    syms t;
    s = t^3 - 3*t;
    v = diff(s , t);
    a = diff(v , t);
    disp("Van toc v = ");
    disp(v);
    disp("Gia toc a = ");
    disp(a);
end