function [] = baitap2()
    subplot(1 , 3 , 1);
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    z = x.^2 .* y .* exp(-x.^2 - y.^2);
    plot3(x , y , z);
    title("Do thi ham so a");

    subplot(1 , 3 , 2);
    t = linspace(0 , 5);
    x = sin(4.*t);
    y = cos(4.*t);
    plot(t , x , t , y);
    title("Do thi ham so b");

    subplot(1 , 3 , 3);
    s = linspace(0 , 2*pi);
    t = linspace(-1 , 1);
    [U, V] = meshgrid(s, t);
    X = (1 + V .* cos(U / 2)) .* cos(U); 
    Y = (1 + V .* cos(U / 2)) .* sin(U); 
    Z = V .* sin(U / 2);                 
    surf(X , Y , Z);
    title("Do thi ham so c");
end