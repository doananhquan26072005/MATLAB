function [] = baitap6()
    A = [1 -1 5 -1
        1 1 -2 3
        3 -1 8 1
        1 3 -9 7];

    for i = 1 : 4
        A(2 , i) = A(2 , i) + (-1) * A(1 , i);
        A(3 , i) = A(3 , i) + (-3) * A(1 , i);
        A(4 , i) = A(4 , i) + (-1) * A(1 , i);
    end

    disp(A);
    for i = 2 : 4
        A(3 , i) = A(3 , i) + (-1) * A(2 , i);
        A(4 , i) = A(4 , i) + (-2) * A(2 , i);
    end
    disp(A);
    disp("rank ma tran tu tinh : 2");
    disp("rank ma tran mathlab ");
    disp(rank(A));
end