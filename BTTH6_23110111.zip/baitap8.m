function [] = baitap8()
    A = input("Nhap ma tran A ");
    if(size(A , 1) ~= size(A , 2))
        disp("A khong phai ma tran vuong!");
    else
        Matran_TG_Tren(A);
        Matran_TG_Duoi(A);
        Matran_DuongCheo(A);
    end
end

function [] = Matran_TG_Tren(A)
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            if i <= j
                A_U(i , j) = A(i , j);
            else
                A_U(i , j) = 0;
            end
        end
    end
    disp(A_U);
end

function [] = Matran_TG_Duoi(A)
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            if i >= j
                A_L(i , j) = A(i , j);
            else
                A_L(i , j) = 0;
            end
        end
    end
    disp(A_L);
end

function [] = Matran_DuongCheo(A)
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            if i == j
                A_D(i , j) = A(i , j);
            else
                A_D(i , j) = 0;
            end
        end
    end
    disp(A_D);
end