function [] = baitap7()
    A = input("Nhap ma tran can tinh tong ");
    n = input("Nhap n = ");
    HamTinh_Tong_Matran(A , n);
end

function [] = HamTinh_Tong_Matran(A , n)
    if n == 1
        for i = 2 : size(A , 1)
            A(1 , :) = A(1 , :) + A(i , :);
        end
        disp(A(1 , :));
    else
        for i = 2 : size(A , 2)
            A(: , 1) = A(: , 1) + A(: , i);
        end
        disp(A(: , 1));
    end
end