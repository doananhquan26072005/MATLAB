function [] = baitap9()
    A = input("Nhap ma tran A ");
    B = input("Nhap ma tran B ");
    if(size(A , 1) ~= size(B , 1) || size(A , 2) ~= size(B , 2))
        disp("Khong the tinh tong 2 ma tran tren!");
    else
        Tong_Matran(A , B);
    end
end

function [] = Tong_Matran(A , B)
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            S(i , j) = A(i , j) + B(i , j);
        end
    end
    disp(S);
end