function [] = baitap5()
    A = [1 2 3 4
        2 4 6 8
        3 6 9 12];

    for i = 1 : 4
        A(3 , i) = A(3 , i) + (-3) * A(1 , i);
    end

    disp(A);

    for i = 1 : 4
        A(2 , i) = A(2 , i) + (-2) * A(1 , i);
    end

    disp(A);
end