function [] = baitap4()
    A = [1 2 3 5 4
        5 6 8 9 11
        3 1 2 5 7
        9 2 5 6 12
        2 5 7 7 14];

    B = [11 12 20 30 32
        1 2 36 3 5
        31 22 25 9 11
        5 6 7 10 12
        15 32 24 34 38];

    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            C(i , j) = A(i , j) + B(i , j);
        end
    end

    D = zeros(size(A , 1) , size(B , 2));
    for i = 1 : size(A , 1)
        for j = 1 : size(B , 2)
            for k = 1 : size(A , 2)
                D(i , j) = D(i , j) + A(i , k) * B(k , j);
            end
        end
    end

    disp("A + B tu tinh toan :");
    disp(C);
    disp("A + B mathlab :");
    disp(A + B);
    disp("A.B tu tinh toan :");
    disp(D);
    disp("A.B mathlab :")
    disp(A*B);
end