function [] = baitap11()
    A = input("Nhap ma tran A ");
    Hang_Matran(A);
end

function [] = Hang_Matran(A)
    disp(rank(A));
end