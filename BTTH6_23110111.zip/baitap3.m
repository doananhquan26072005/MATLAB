function [] = baitap3()
    A = [1 2 3
        5 6 9
        10 11 15];

    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            if i <= j
                A_U(i , j) = A(i , j);
            else
                A_U(i , j) = 0;
            end
            if i >= j
                A_L(i , j) = A(i , j);
            else
                A_L(i , j) = 0;
            end
            if i == j
                A_D(i , j) = A(i , j);
            else
                A_D(i , j) = 0;
            end
        end
    end

    disp(A_U);
    disp(A_L);
    disp(A_D);
end