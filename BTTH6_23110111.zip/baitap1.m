function [] = baitap1()
    A = [2 4 1
        6 7 2
        3 5 9];

    X = A(1,:);
    Y = A(2:3,:);
    S_r = A(1,:) + A(2,:) + A(3,:);
    S_c = A(:,1) + A(:,2) + A(:,3);
    Max = A(1,1);
    Min = A(1,1);
    Sum = 0;
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            if Max < A(i , j)
                Max = A(i , j);
            end
            if Min > A(i , j)
                Min = A(i , j);
            end
            Sum = Sum + A(i , j);
        end
    end

    disp(X);
    disp(Y);
    disp(S_r);
    disp(S_c);
    disp(Max);
    disp(Min);
    disp(Sum);
end