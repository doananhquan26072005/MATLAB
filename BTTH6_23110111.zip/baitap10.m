function [] = baitap10()
    A = input("Nhap ma tran A ");
    B = input("Nhap ma tran B ");
    if(size(A , 2) ~= size(B , 1))
        disp("Khong the tinh tich 2 ma tran tren!");
    else
        Tich_Matran(A , B);
    end
end

function [] = Tich_Matran(A , B)
    P = zeros(size(A , 1) , size(B , 2));
    for i = 1 : size(A , 1)
        for j = 1 : size(B , 2)
            for k = 1 : size(A , 2)
                P(i , j) = P(i , j) + A(i , k) * B(k , j);
            end
        end
    end
    disp(P);
end