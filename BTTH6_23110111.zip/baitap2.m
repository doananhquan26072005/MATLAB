function [] = baitap2()
    A = randi([-10 , 10] , [4 , 4]);
    
    for i = 1 : size(A , 1)
        for j = 1 : size(A , 2)
            A1(i , j) = A(i , j) + 15;
            A2(i , j) = A(i , j) ^ 2;
            A3(i , j) = A(i , j);
            if(i == 1 || i == 2)
                A3(i , j) = A(i , j) + 10;
            end
            A4(i , j) = A(i , j);
            if(j == 1 || j == 4)
                A4(i , j) = A(i , j) + 10;
            end
            A5(i , j) = A(i , j) ^ (-1);
            A6(i , j) = A(i , j) ^ (1 / 2);
        end
    end

    disp(A);
    disp(A1);
    disp(A2);
    disp(A3);
    disp(A4);
    disp(A5);
    disp(A6);
end