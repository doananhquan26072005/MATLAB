function [] = baitap2c()
    syms x;
    f = 2*x - 5*x^(3/4);
    f1 = diff(f,x);
    f2 = diff(f1,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
end