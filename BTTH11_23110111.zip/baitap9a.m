function [] = baitap9a()
    r1 = -1;
    r2 = 0;
    r3 = 1;
    r4 = 2;

    syms n;
    if limit(n * r1 ^ n , n , inf) == 0
        disp("Chuoi n * r ^ n voi r = -1 hoi tu");
    else 
        disp("Chuoi n * r ^ n voi r = -1 khong hoi tu");
    end

    if limit(n * r2 ^ n , n , inf) == 0
        disp("Chuoi n * r ^ n voi r = 0 hoi tu");
    else 
        disp("Chuoi n * r ^ n voi r = 0 khong hoi tu");
    end

    if limit(n * r3 ^ n , n , inf) == 0
        disp("Chuoi n * r ^ n voi r = 1 hoi tu");
    else 
        disp("Chuoi n * r ^ n voi r = 1 khong hoi tu");
    end

    if limit(n * r4 ^ n , n , inf) == 0
        disp("Chuoi n * r ^ n voi r = 2 hoi tu");
    else 
        disp("Chuoi n * r ^ n voi r = 2 khong hoi tu");
    end
end