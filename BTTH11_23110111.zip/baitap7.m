function [] = baitap7()
    Sa = 0;
    Sb = 0;
    Sc = 0;
    Sd = 0;
    for i = 1 : 20
        Sa = Sa + 12/(-5)^i;
        Sb = Sb + tan(i);
        Sc = (1 / 15) ^ (1.5) - 1 / (i + 1) ^ (1.5);
        Sd = 1 / (i * (i + 1));
    end

    disp("Tong rieng 20 cua a la = ");
    disp(Sa);
    disp("Tong rieng 20 cua b la = ");
    disp(Sb);
    disp("Tong rieng 20 cua c la = ");
    disp(Sc);
    disp("Tong rieng 20 cua d la = ");
    disp(Sd);

    k = 1:20;
    subplot(2,2,1);
    xa = 12 ./ (-5).^k;
    Sa = cumsum(xa);
    plot(k, xa, 'b-', k, Sa, 'r-');
    title('cau a');
    legend('Số hạng riêng x_k', 'Tổng riêng S_N');
    xlabel('N');
    ylabel('Giá trị');

    subplot(2,2,2);
    xb = tan(k);
    Sb = cumsum(xb);
    plot(k, xb, 'b-', k, Sb, 'r-');
    title('cau b');
    legend('Số hạng riêng x_k', 'Tổng riêng S_N');
    xlabel('N');
    ylabel('Giá trị');

    subplot(2,2,3);
    xc = 1/15^(1.5) - 1 ./ (k+1).^1.5;
    Sc = cumsum(xc);
    plot(k, xc, 'b-', k, Sc, 'r-');
    title('cau c');
    legend('Số hạng riêng x_k', 'Tổng riêng S_N');
    xlabel('N');
    ylabel('Giá trị');

    subplot(2,2,4);
    xd = 1 ./ (k .* (k + 1));
    Sd = cumsum(xd);
    plot(k, xd, 'b-', k, Sd, 'r-');
    title('cau d');
    legend('Số hạng riêng x_k', 'Tổng riêng S_N');
    xlabel('N');
    ylabel('Giá trị');
end