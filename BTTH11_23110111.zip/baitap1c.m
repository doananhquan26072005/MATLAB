function [] = baitap1c()
    for i = 0 : 4
        disp(cos(i * pi / 6));
    end
    syms x;
    disp(limit(cos(x * pi / 6) , x , inf));
end