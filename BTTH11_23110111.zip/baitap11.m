function [] = baitap11()
    fa = @(x) exp(x);
    fb = @(x) sin(x) / x;
    fc = @(x) 2^x;
    fd = @(x) 1 / (x^2 + 2);

     a = input("Nhap can a = ");
     b = input("Nhap can b = ");
     N = input("Nhap so diem N = ");
     TH = input("Ban muon tim dao ham cua cau nao ('a','b','c','d') : ");
     if TH == 'a'
        f = fa;
     elseif TH == 'b'
        f = fb;
     elseif TH == 'c'
        f = fc;
     else 
        f = fd;
     end
    disp(Xapxi_tichphan(f , a , b , N));
end

function I = Xapxi_tichphan( f , a , b , N )
    I = 0;
    for i = 0 : N - 1
        xi = a + (b - a) * i / N;
        xi1 = a + (b - a) * (i + 1) / N;
        I = I + (xi + xi1) * (f(xi) + f(xi1));
    end
    I = 1/2 * I;
end