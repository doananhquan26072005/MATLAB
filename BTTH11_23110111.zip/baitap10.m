function [] = baitap10()
    syms x;

    fa = int(exp(x) , x , 0 , pi);
    disp("Tich phan cau a la :");
    disp(fa);

    fb = int( sin(x)/x, x , 0 , 1);
    disp("Tich phan cau b la :");
    disp(fb);

    fc = int(2^x , x , 0 , 2);
    disp("Tich phan cau c la :");
    disp(fc);

    fd = int(1 / (x^2 + 2) , x , 0 , 1);
    disp("Tich phan cau d la :");
    disp(fd);
end