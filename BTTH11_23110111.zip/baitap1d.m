function [] = baitap1d()
    a = 3;
    disp(a);
    for i = 2 : 5
        a = 2 * a - 1;
        disp(a);
    end
    disp(inf);
end