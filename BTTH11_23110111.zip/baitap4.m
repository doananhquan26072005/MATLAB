function [] = baitap4()
    subplot(2,2,1);
    x = linspace(0 , 4);
    f = log(x - 2);
    plot(x , f);
    title("Do thi ham so a");

    subplot(2,2,2);
    x1 = linspace(-2 , 0);
    x2 = linspace(0 , 2);
    f1 = exp(x);
    f2 = x.^2;
    plot(x1 , f1 , x2 , f2);
    title("Do thi ham so b");

    subplot(2,2,3);
    x = linspace(-1 , 3);
    f = (x.^2 - x) ./ (x.^2 - 1);
    plot(x , f);
    title("Do thi ham so c");

    subplot(2,2,4);
    x1 = linspace(-2 , 0);
    x2 = linspace(0 , 2);
    f1 = cos(pi * x);
    f2 = 1 - x.^2;
    plot(x1 , f1 , x2 , f2);
    title("Do thi ham so d");
end