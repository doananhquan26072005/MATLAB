function [] = baitap9b()
    r1 = -1;
    r2 = 0;
    r3 = 1;
    r4 = 2;

    syms n;
    if limit(1 / n ^ r1, n , inf) == 0
        disp("Chuoi 1 / n ^ r voi r = -1 hoi tu");
    else 
        disp("Chuoi 1 / n ^ r voi r = -1 khong hoi tu");
    end

    if limit(1 / n ^ r2 , n , inf) == 0
        disp("Chuoi 1 / n ^ r voi r = 0 hoi tu");
    else 
        disp("Chuoi 1 / n ^ r voi r = 0 khong hoi tu");
    end

    if limit(1 / n ^ r3 , n , inf) == 0
        disp("Chuoi 1 / n ^ r voi r = 1 hoi tu");
    else 
        disp("Chuoi 1 / n ^ r voi r = 1 khong hoi tu");
    end

    if limit(1 / n ^ r4 , n , inf) == 0
        disp("Chuoi 1 / n ^ r voi r = 2 hoi tu");
    else 
        disp("Chuoi 1 / n ^ r voi r = 2 khong hoi tu");
    end
end