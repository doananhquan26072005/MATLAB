function [] = baitap1a()
    for i = 3 : 8
        disp(sqrt(i - 3));
    end
    syms x;
    disp(limit(sqrt(x - 3) , x , inf));
end