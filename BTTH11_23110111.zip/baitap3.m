function [] = baitap3()
    fa = @(x) x^6 +x^4 -3*x^3 -16*x;
    fb = @(x) x^(1/2) + x^(1/3) + x*x^(1/2);
    fc = @(x) 2*x - 5*x^(3/4);
    fd = @(x) sin(x) + log(x) + 1/x^2;

     n = input("Nhap cap dao ham ban muon n = ");
     x0 = input("Nhap diem can tinh gia tri dao ham x0 = ");
     h = input("Nhap buoc nhay h = ");
     TH = input("Ban muon tim dao ham cua cau nao ('a','b','c','d') : ");
     if TH == 'a'
        f = fa;
     elseif TH == 'b'
        f = fb;
     elseif TH == 'c'
        f = fc;
     else 
        f = fd;
     end
    disp(Xapxi_daoham(f , n , x0 , h));
end

function df = Xapxi_daoham( f , n , x0 , h ) 
    if n == 1
        df = (f(x0 + h) - f(x0 - h)) / 2 * h;
    elseif n == 2
        df = (f(x0 + h) - 2*f(x0) + f(x0 - h)) / h^2;
    end
end