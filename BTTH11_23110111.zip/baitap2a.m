function [] = baitap2a()
    syms x;
    f = x^6 +x^4 -3*x^3 -16*x;
    f1 = diff(f,x);
    f2 = diff(f1,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
end