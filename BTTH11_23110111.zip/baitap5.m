function [] = baitap5()
    subplot(1,2,1);
    x = linspace(-2 , 2);
    f = 1 ./ (1 + exp(1 ./ x));
    plot(x , f);
    title("Do thi ham so a");

    subplot(1,2,2);
    x = linspace(-2*pi , 2*pi);
    f = log(tan(x).^2);
    plot(x , f);
    title("Do thi ham so a");
end