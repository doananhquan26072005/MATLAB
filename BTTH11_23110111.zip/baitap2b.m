function [] = baitap2b()
    syms x;
    f = x^(1/2) + x^(1/3) + x*x^(1/2);
    f1 = diff(f,x);
    f2 = diff(f1,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
end