function [] = baitap2d()
    syms x;
    f = sin(x) + log(x) + 1/x^2;
    f1 = diff(f,x);
    f2 = diff(f1,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
end