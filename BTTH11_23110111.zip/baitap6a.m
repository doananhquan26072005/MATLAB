function [] = baitap6a()
    syms x;
    limLeft = limit(x*sin(1/x) , x , 0 , 'left');
    limRight = limit(x*sin(1/x) , x , 0 , 'right');
    if limLeft == limRight
        disp("Ton tai f'(0)");
    else
        disp("Khong ton tai f'(0)");
    end
end