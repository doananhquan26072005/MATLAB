function [] = baitap1b()
    for i = 0 : 4
        disp((i + 1) / (3 * i - 1));
    end
    syms x;
    disp(limit((x + 1) / (3 * x - 1) , x , inf));
end