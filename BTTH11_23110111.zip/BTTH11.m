%Ho va ten: Doan Anh Quan
%MSSV: 23110111
clear
close all
format long
%  baitap1a();
%  baitap1b();
%  baitap1c();
%  baitap1d();
%  baitap2a();
%  baitap2b();
%  baitap2c();
%  baitap2d();
%  baitap3();
%  baitap4();
%  baitap5();
%  baitap6a();
%  baitap6b();
%  baitap7();
%  baitap8();
%  baitap9a();
%  baitap9b();
%  baitap10();
%  baitap11();
%  baitap12();