function [] = baitap8()
    x = linspace(-4,2);
    f = 2.*x.^3 + 3.*x.^2 -12.*x + 1;
    plot(x , f);
    hold on;
    a = [-2 1];
    b = [21 -6];
    plot(a , b , '*r');
end