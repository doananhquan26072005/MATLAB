function [] = baitap1()
    x = input('nhap x = ');
    y = input('nhap y = ');
    u = [x ; x + y ; x - y ; x * y];
    v = [sqrt(x) ; 1 / (x + y) ; x ^ y ; x ^ 2 + y ^ 2];
    w = [(x ^ 4 + y ^ 5) ^ (1 / 4) ; x * log10(y) ; x + sqrt(y) + 1];
    disp(u);
    disp(v);
    disp(w);
end