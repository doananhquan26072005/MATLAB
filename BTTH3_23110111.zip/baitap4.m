function [] = baitap4()
    a = input("nhap vector a = ");
    sum_chan = 0;
    sum_le = 0;
    sum_snt_chan = 0;
    sum_snt_le = 0;
    sum_chinh_phuong = 0;
    for i = 1 : length(a)
        if(check_snt(a(i)) == 0 && a(i) > 1)
            if(mod(a(i) , 2) == 0)
                sum_snt_chan = sum_snt_chan + a(i);
            else
                sum_snt_le = sum_snt_le + a(i);
            end
        end

        if(mod(a(i) , 2) == 0)
            sum_chan = sum_chan + a(i);
        else
            sum_le = sum_le + a(i);
        end

        if(sqrt(a(i)) * sqrt(a(i)) == a(i))
            sum_chinh_phuong = sum_chinh_phuong + a(i);
        end
    end
    disp(sum_chan);
    disp(sum_le);
    disp(sum_snt_chan);
    disp(sum_snt_le);
    disp(sum_chinh_phuong);
end

function [check] = check_snt(n)
    check = 0;
    for i = 2:sqrt(n)
        if(mod(n,i)==0)
            check = 1;
            break;
        end
    end
end