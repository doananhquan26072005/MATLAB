function [] = baitap12()
    n = input("nhap n = ");
    a = floor(n / 100);
    switch a
        case 1
            disp("mot tram ");
        case 2
            disp("hai tram")
        case 3
            disp("ba tram")
        case 4
            disp("bon tram")
        case 5
            disp("nam tram")
        case 6
            disp("sau tram")
        case 7
            disp("bay tram")
        case 8
            disp("tam tram")
        case 9
            disp("chin tram")
    end
    b = mod(floor(n / 10) , 10);
    switch b
        case 1
            disp("muoi ");
        case 2
            disp("hai muoi")
        case 3
            disp("ba muoi")
        case 4
            disp("bon muoi")
        case 5
            disp("nam muoi")
        case 6
            disp("sau muoi")
        case 7
            disp("bay muoi")
        case 8
            disp("tam muoi")
        case 9
            disp("chin muoi")
        case 0
            disp("le ")
    end

    c = mod(n , 10);
    switch c
        case 1
            disp("mot");
        case 2
            disp("hai")
        case 3
            disp("ba")
        case 4
            disp("bon")
        case 5
            disp("nam")
        case 6
            disp("sau")
        case 7
            disp("bay")
        case 8
            disp("tam")
        case 9
            disp("chin")
    end
end