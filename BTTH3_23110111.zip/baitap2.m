function [] = baitap2()
    a(1) = -21;
    for i = 2 : 14
        a(i) = round(rand() * 20 + 1);
    end
    a(15) = 12;
    disp(a);
end