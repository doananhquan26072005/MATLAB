function [] = baitap7()
    n = round(rand() * 20 + 1);
    am = 0;
    duong = 0;
    khong = 0;
    for i = 1 : n
        a(i) = round(rand() * 100 + (-50));
        if(a(i) < 0)
            am = am + 1;
        elseif (a(i) > 0)
            duong = duong + 1;
        else 
            khong = khong + 1;
    end
    disp(a);
    disp(am);
    disp(duong);
    disp(khong);
end