function [] = baitap6()
    sum = 0;
    for i = 1 : 1000000
        a(i) = round(rand() * 10);
        sum = sum + a(i) ^ 2;
    end
    disp(sum);
end