function [] = baitap10()
    for i = 1 : 1000
        if(check(i) == 1)
            disp(i);
        end
    end
end

function [dd] = check(n)
    sum = 0;
    for i = 1 : n - 1
        if(mod(n,i) == 0)
            sum = sum + i;
        end
    end
    if(sum == n) dd = 1;
    else dd = 0;
    end
end