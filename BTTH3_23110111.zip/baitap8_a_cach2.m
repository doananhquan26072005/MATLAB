function [] = baitap8_a_cach2()
    sum = 5 / 2;
    k = 1;
    while sum <= 4
        k = k + 1;
        sum = sum + 5 / (k * (k + 1));
    end
    disp(k - 1);
end