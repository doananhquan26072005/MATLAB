function [] = baitap8_c_cach1()
    sum = 1 / 2;
    for k = 2 : 1000000
        sum = sum + k ^ 2 / (k ^ 2 + 1);
        if(sum >= 10)
            break;
        end
    end
    disp(k);
end