function [] = baitap8_c_cach2()
    sum = 1 / 2;
    k = 1;
    while sum < 10
        k = k + 1;
        sum = sum + k ^ 2 / (k ^ 2 + 1);
    end
    disp(k);
end