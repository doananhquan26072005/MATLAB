function [] = baitap5()
    sum = 2;
    a(1) = 1;
    a(2) = 1;
    for i = 3 : 10
        a(i) = a(i - 1) + a(i - 2);
        sum = sum + a(i);
    end
    disp(sum);

    n = 11;
    while a(n - 1) + a(n - 2) < 1000
        a(n) = a(n - 1) + a(n - 2);
        n = n + 1;
    end
    disp(n - 1);

    sum = 0;
    for i = 3 : 50
        a(i) = a(i - 1) + a(i - 2);
        if(mod(a(i) , 2) == 0 || mod(a(i) , 5) == 0)
            sum = sum + a(i);
        end
    end
    disp(sum);
end