function [] = baitap8_b_cach1()
    sum = 1 / 4;
    for k = 2 : 1000000
        sum = sum + 1 / (k * (k + 3));
        if(sum >= 1/2)
            break;
        end
    end
    disp(k);
end