function [] = baitap8_a_cach1()
    sum = 5 / 2;
    for k = 2 : 1000000
        sum = sum + 5 / (k * (k + 1));
        if(sum > 4)
            break;
        end
    end
    disp(k - 1);
end