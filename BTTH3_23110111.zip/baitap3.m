function [] = baitap3()
    a = input("nhap vector a = ");
    Max = a(1); Min = a(1);
    for i = 2 : length(a)
        if(a(i) > Max)
            Max = a(i);
        end
        if (a(i) < Min)
            Min = a(i);
        end
    end
    disp(Max);
    disp(Min);
end