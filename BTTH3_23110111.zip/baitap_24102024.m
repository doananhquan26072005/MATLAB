clc
clear
close all
format long
%  baitap1;
%  baitap2;
%  baitap3;
%  baitap4;
%  baitap5;
%  baitap6;
%  baitap7;
%  baitap8_a_cach1;
%  baitap8_a_cach2;
%  baitap8_b_cach1;
%  baitap8_b_cach2;
%  baitap8_c_cach1;
%  baitap8_c_cach2;
%  baitap9;
%  baitap10;
%  baitap11;
%  baitap12;