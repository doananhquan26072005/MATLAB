function [] = baitap8_b_cach2()
    sum = 1 / 4;
    k = 1;
    while sum < 1/2
        k = k + 1;
        sum = sum + 1 / (k * (k + 3));
    end
    disp(k);
end