function [] = baitap9()
    a = input("nhap a = ");
    b = input("nhap b = ");
    tich = a * b;
    if(b > a) 
        swap = a;
        a = b;
        b = swap;
    end
    r = mod(a , b);
    while r ~= 0
        b = r;
        a = b;
        r = mod(a , b);
    end
    disp("UCLN la ");
    disp(b);
    disp("BCNN la ");
    disp(tich / b);
end