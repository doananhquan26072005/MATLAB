clear;
clc;
n = input('nhap n = ');
dapan = 1;
for i = 1 : n
    dapan = dapan * i;
end
disp(dapan)