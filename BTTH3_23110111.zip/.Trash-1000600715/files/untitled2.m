clc;
clear;
n = input('nhap n = ');
sum = 0;
for i = 1 : n
    sum = sum + i;
end
disp(sum);