function [] = baitap1b()
    syms x;
    f = x^(1/3) - 1/3 * x;
    f1 = diff(f,x);
    f2 = diff(f1,x);
    f3 = diff(f2,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
    disp("Dao ham f''' la :");
    disp(f3);
end