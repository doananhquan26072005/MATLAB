function [] = baitap4d()
    syms x;
    syms y;
    f = cos(y ^ 2);
    f1 = int(f, y , x , 1);
    f2 = int(f1 , x , 0 , 1);
    disp(f2);
end