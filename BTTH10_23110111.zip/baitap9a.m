function [] = baitap9a()
    syms x;
    syms y;
    syms z;
    f = y;
    A = int(f , z , x-y , x+y);
    A = int(A , y , 0 , x);
    A = int(A , x , 0 , 3);
    disp(A);
end