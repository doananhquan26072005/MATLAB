function [] = baitap6d()
    syms x;
    syms y;
    syms z;
    u = [2*x^2+3*y^2+2*x*y*z , cos(x*y)*sin(x*z)*tan(y*z) , exp(x+y)*log(x*y*z)];

    for i = 1 : 3
        for j = 1 : 3
            if(j == 1) 
                J(i , j) = diff(u(1 , i) , x);
            end
            if(j == 2) 
                J(i , j) = diff(u(1 , i) , y);
            end
            if(j == 3) 
                J(i , j) = diff(u(1 , i) , z);
            end
        end
    end
    disp(J);
end