function [] = baitap7b()
    syms x;
    syms y;
    syms z;
    f = exp(-y^2-z^2)*cos(sqrt(1+x-7));
    Laplace = diff(f , x , 2) + diff(f , y , 2) + diff(f , z , 2); 
    disp("Ket qua cua toan tu Laplace la ");
    disp(Laplace);
end