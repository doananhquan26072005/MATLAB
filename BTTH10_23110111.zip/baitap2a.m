function [] = baitap2a()
    syms x;
    f = (1 - x^2) ^ (1/2);
    f1 = int(f,x);
    disp("Tich f' la :");
    disp(f1);
end