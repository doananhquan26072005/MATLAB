function [] = baitap3a()
    syms x;
    syms y;
    f = x^2 + x*y + y^2 + y;
    f1 = diff(f, x);
    f2 = diff(f, x , 2);
    f3 = diff(diff(f , x) , y);
    f4 = diff(f, y);
    f5 = diff(f, y , 2);
    disp("Dao ham rieng cua f theo x la :");
    disp(f1);
    disp("Dao ham rieng cua f theo x 2 lan la :");
    disp(f2);
    disp("Dao ham rieng cua f theo x va theo y la :");
    disp(f3);
    disp("Dao ham rieng cua f theo y la :");
    disp(f4);
    disp("Dao ham rieng cua f theo y 2 lan la :");
    disp(f5);
end