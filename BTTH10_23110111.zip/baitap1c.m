function [] = baitap1c()
    syms x;
    f = cos(2*x);
    f1 = diff(f,x);
    f2 = diff(f1,x);
    f3 = diff(f2,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
    disp("Dao ham f''' la :");
    disp(f3);
end