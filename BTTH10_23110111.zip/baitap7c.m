function [] = baitap7c()
    syms x;
    syms y;
    syms z;
    syms t;
    f = log(2*x*y/(x^2+2*y^2+3*z^2)) + x*y*z*exp(x*y*z)/sqrt(x^2-y^2+z^2-t^2);
    Laplace = diff(f , x , 2) + diff(f , y , 2) + diff(f , z , 2) + diff(f , t , 2); 
    disp("Ket qua cua toan tu Laplace la ");
    disp(Laplace);
end