function [] = baitap5b()
    x = linspace(-1 , 3);
    y1 = 2 * x;
    y2 = x.^2;
    plot(x , y1 , 'r-' , x , y2 , '-b');
    grid on;
    
    syms xn;
    syms yn;
    yn1 = 2 * xn^2;
    yn2 = 1 + xn^2;
    V = int(int(1 , yn , yn2 , yn1) , xn , 0 , 2);
    disp("the tich cua mien D la :");
    disp(V);
end