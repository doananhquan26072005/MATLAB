function [] = baitap5c()
    x = linspace(-3 , 6);
    y1 = x - 1;
    y2 = sqrt(2 * x + 6);
    y3 = -sqrt(2 * x + 6);
    plot(x , y1 , 'r-' , x , y2 , '-b' , x , y3 , '-b');
    grid on;
    
    syms xn;
    syms yn;
    yn1 = xn - 1;
    yn2 = sqrt(2 * xn^2 + 6);
    yn3 = -sqrt(2 * xn^2 + 6);
    V = int(int(1 , yn , yn3 , 0) , xn , -3 , -1);
    V = V + int(int(1 , yn , yn1 , 0) , xn , -1 , 1);
    V = V + int(int(1 , yn , yn2 , yn1) , xn , 0 , 5);
    disp("the tich cua mien D la :");
    disp(V);
end