function [] = baitap9c()
    syms x;
    syms y;
    syms z;
    f = z/(x^2 + z^2);
    A = int(f , x , 0 , z);
    A = int(A , z , y , 4);
    A = int(A , y , 1 , 4);
    disp(A);
end