function [] = baitap2e()
    syms x;
    f = tan(x);
    f1 = int(f , x , pi/4 , pi/3);
    disp("Tich f' la :");
    disp(f1);
end