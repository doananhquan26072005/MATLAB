function [] = baitap2b()
    syms x;
    f = sin(x ^ (1/2));
    f1 = int(f,x);
    disp("Tich f' la :");
    disp(f1);
end