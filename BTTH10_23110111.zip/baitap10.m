function [] = baitap10()
    syms x;
    x0 = 0;
    n = 6;
    f = exp(x);
    P = DaThuc_Taylor(f , n , x0);
end

function [P] = DaThuc_Taylor(f , n , x0)
    P = expx0);
    for k = 1 : n
        
    end
end