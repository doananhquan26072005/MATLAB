function [] = baitap2c()
    syms x;
    f = cos(x) ^ 4;
    f1 = int(f , x , 0 , pi / 2);
    disp("Tich f' la :");
    disp(f1);
end