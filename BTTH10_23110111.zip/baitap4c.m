function [] = baitap4c()
    syms x;
    syms y;
    f = 1 / sqrt(y^2 - x^2);
    f1 = int(int(f, x) , y);
    disp(f1);
end