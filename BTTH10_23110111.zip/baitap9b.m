function [] = baitap9b()
    syms x;
    syms y;
    syms z;
    f = exp(x / y);
    A = int(f , z , 0 , x*y);
    A = int(A , x , y , 1);
    A = int(A , y , 0 , 1);
    disp(A);
end