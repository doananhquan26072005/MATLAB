function [] = baitap2d()
    syms x;
    f = abs(x - 5);
    f1 = int(f , x , 0 , 10);
    disp("Tich f' la :");
    disp(f1);
end