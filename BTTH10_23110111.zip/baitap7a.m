function [] = baitap7a()
    syms x;
    syms y;
    f = sin(x^2+y^2)/(x^2+y^2);
    Laplace = diff(f , x , 2) + diff(f , y , 2);
    disp("Ket qua cua toan tu Laplace la ");
    disp(Laplace);
end