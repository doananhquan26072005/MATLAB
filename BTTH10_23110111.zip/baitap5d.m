function [] = baitap5d()
    x = linspace(-2 , 2);
    y1 = x;
    y2 = x.^3;
    plot(x , y1 , 'r-' , x , y2 , '-b');
    grid on;
    
    syms xn;
    syms yn;
    yn1 = xn;
    yn2 = xn ^ 3;
    V = int(int(1 , yn , yn1 , yn2) , xn , -1 , 0);
    V = V + int(int(1 , yn , yn2 , yn1) , xn , 0 , 1);
    disp("the tich cua mien D la :");
    disp(V);
end