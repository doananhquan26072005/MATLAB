function [] = baitap8b()
    syms x;
    syms y;
    f = exp(-x^2-y^2);
    f1 = int(int(f , x , -inf , inf) , y , -inf , inf); 
    disp(f1);
end