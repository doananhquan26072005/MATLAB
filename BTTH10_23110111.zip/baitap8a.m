function [] = baitap8a()
    syms x;
    f = exp(-x^2);
    f1 = int(f , x , -inf , inf); 
    disp(f1);
end