function [] = baitap4e()
    syms x;
    syms y;
    f = y * exp(x^2) / x^3;
    f1 = int(f, x , sqrt(y) , 1);
    f2 = int(f1 , y , 0 , 1);
    disp(f2);
end