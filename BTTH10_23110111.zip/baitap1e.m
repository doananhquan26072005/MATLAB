function [] = baitap1e()
    syms x;
    f = x ^ (1/2) - x ^ (1/4);
    f1 = diff(f,x);
    f2 = diff(f1,x);
    f3 = diff(f2,x);
    disp("Dao ham f' la :");
    disp(f1);
    disp("Dao ham f'' la :");
    disp(f2);
    disp("Dao ham f''' la :");
    disp(f3);
end