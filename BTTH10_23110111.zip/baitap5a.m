function [] = baitap5a()
    x = linspace(-2 , 2);
    y1 = 2 * x.^2;
    y2 = 1 + x.^2;
    plot(x , y1 , 'r-' , x , y2 , '-b');
    grid on;
    
    syms xn;
    syms yn;
    yn1 = 2 * xn^2;
    yn2 = 1 + xn^2;
    V = int(int(1 , yn , yn1 , yn2) , xn , -1 , 1);
    disp("the tich cua mien D la :");
    disp(V);
end