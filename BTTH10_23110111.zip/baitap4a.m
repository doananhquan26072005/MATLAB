function [] = baitap4a()
    syms x;
    syms y;
    f = cos(y ^ 3);
    f1 = int(f, y , 0 , x^3);
    f2 = int(f1 , x , 0 , 1);
    disp(f2);
end