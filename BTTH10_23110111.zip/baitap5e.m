function [] = baitap5e()
    x = linspace(0 , 5);
    y1 = x - 2;
    y2 = sqrt(x);
    y3 = -sqrt(x);
    plot(x , y1 , 'r-' , x , y2 , '-b' , x , y3 , '-b');
    grid on;
    
    syms xn;
    syms yn;
    yn1 = xn - 2;
    yn2 = sqrt(xn);
    yn3 = -sqrt(xn);
    V = int(int(1 , yn , yn3 , 0) , xn , 0 , 1);
    V = V + int(int(1 , yn , yn1 , 0) , xn , 1 , 2);
    V = V + int(int(1 , yn , yn2 , yn1) , xn , 0 , 4);
    disp("the tich cua mien D la :");
    disp(V);
end