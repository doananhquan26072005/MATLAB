function [] = baitap4b()
    syms x;
    syms y;
    f = 1 / (4 - x^2);
    f1 = int(f, x , -1 , y);
    f2 = int(f1 , y , -1 , 1);
    disp(f2);
end