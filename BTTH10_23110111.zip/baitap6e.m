function [] = baitap6e()
    syms x;
    syms y;
    syms z;
    u = [sqrt(x+log(y*z)) , x/(y^3+z^2) , y*z/(sqrt(x^2-1))];

    for i = 1 : 3
        for j = 1 : 3
            if(j == 1) 
                J(i , j) = diff(u(1 , i) , x);
            end
            if(j == 2) 
                J(i , j) = diff(u(1 , i) , y);
            end
            if(j == 3) 
                J(i , j) = diff(u(1 , i) , z);
            end
        end
    end
    disp(J);
end