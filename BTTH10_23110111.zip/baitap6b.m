function [] = baitap6b()
    syms x;
    syms y;
    syms z;
    u = [5*x^3 - x^2*y^2 + tan(x) , exp(x^2+y^2+z^2) , x^5*y-x^2*y-x^3*z];

    for i = 1 : 3
        for j = 1 : 3
            if(j == 1) 
                J(i , j) = diff(u(1 , i) , x);
            end
            if(j == 2) 
                J(i , j) = diff(u(1 , i) , y);
            end
            if(j == 3) 
                J(i , j) = diff(u(1 , i) , z);
            end
        end
    end
    disp(J);
end