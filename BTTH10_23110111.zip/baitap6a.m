function [] = baitap6a()
    syms x;
    syms y;
    syms z;
    u = [sin(x) + cos(x) , x^2 + 3*x - 4 , log(x) + y^2 + sqrt(z)];

    for i = 1 : 3
        for j = 1 : 3
            if(j == 1) 
                J(i , j) = diff(u(1 , i) , x);
            end
            if(j == 2) 
                J(i , j) = diff(u(1 , i) , y);
            end
            if(j == 3) 
                J(i , j) = diff(u(1 , i) , z);
            end
        end
    end
    disp(J);
end