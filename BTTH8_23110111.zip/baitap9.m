function [] = baitap9()
    u = linspace(0 , 2 * pi);
    v = linspace(-5 , 5);
    [U , V] = meshgrid(u , v);
    x = cos(U);
    y = sin(U);
    z = V;
    mesh(x , y , z);
    axis equal;
end