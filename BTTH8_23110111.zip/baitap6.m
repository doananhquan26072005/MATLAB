function [] = baitap6()
    u = linspace(0 , 2 * pi);
    v = linspace(- pi /2 , pi / 2);
    [U , V] = meshgrid(u , v);
    x = cos(U) .* cos(V);
    y = cos(V) .* sin(U);
    z = sin(V);
    mesh(x,y,z);
    axis equal;
end