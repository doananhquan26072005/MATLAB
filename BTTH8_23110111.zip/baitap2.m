function [] = baitap2()
    A = ["coca" , "pepsi" , "tinh khiet" , "khac"];
    B = [850 720 600 320];
    piechart(B , A);
    title("Bieu do quat minh hoa thi truong do uong");
end

