function [] = baitap5()
    t = linspace(0 , 6 * pi);
    x = sin(t);
    y = cos(t);
    z = t;
    plot3(x , y , z);
    axis equal;
end