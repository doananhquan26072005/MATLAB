function [] = baitap4()
    t = linspace(0 , 2 * pi);
    x = 5 * sin(t);
    y = 5 * cos(t);
    plot(x , y);
    axis equal;
end