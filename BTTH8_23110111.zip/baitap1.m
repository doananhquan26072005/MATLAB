function [] = baitap1()
    A = [5 2 1
        8 7 3
        9 8 6];
    bar(A);
    xlabel("Do thi cot bieu dien A");
end

