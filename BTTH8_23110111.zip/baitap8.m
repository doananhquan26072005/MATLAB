function [] = baitap8()
    t = linspace(0 , 6 * pi);
    x = sqrt(t) .* sin(2 .* t);
    y = sqrt(t) .* cos(2 .* t);
    z = 0.5 .* t;
    plot3(x , y , z);
    axis equal;
end