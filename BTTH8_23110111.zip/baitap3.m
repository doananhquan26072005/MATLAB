function [] = baitap3()
    subplot(2,2,1);
    x = linspace(-4 , 4);
    y = linspace(-4 , 4);
    plot3(x , y , x.^2 .* y .* exp(-x.^2-y.^2));
    title('Do thi ham so x^2ye^(-x^2 - y^2)');
    subplot(2,2,2);
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    plot3(x , y , 0.5 .* abs(x) + 0.5 .*abs(y));
    title('Do thi ham so 0.5|x| + 0.5|y|');
    subplot(2,2,3);
    x = linspace(-10 , 10);
    y = linspace(-10 , 10);
    plot3(x , y , sin(sqrt(x.^2 + y.^2)) ./ sqrt(x.^2 + y.^2));
    title('Do thi ham so sin(R) / R');
end

