function [] = baitap5a()
    x = linspace(-3 , 3);
    y = x.^3 - 3*x;
    Min = islocalmin(y);
    Max = islocalmax(y);
    plot(x , y , x(Min) , y(Min) ,'r*' , x(Max) , y(Max) , 'bo');
    legend ('',' la cuc tieu',' la cuc dai');
    xlabel('do thi ham f(x)')
end