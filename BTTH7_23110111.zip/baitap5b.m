function [] = baitap5b()
    x = linspace(-3 , 3);
    y = x.^3 - 3*x;
    y1 = 3*x.^2 - 3;
    y2 = 6*x;
    plot(x , y1 , 'r-' , x , y2 , 'b-');
    xlabel('do thi dao ham bac 1 va 2 cua f(x)');
    legend ('dao ham bac 1 ham f','dao ham bac 2 ham f');
end