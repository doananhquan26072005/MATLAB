function [] = baitap9()
    X0 = input("Nhap toa do diem A theo kieu mang = ");
    a = input("Nhap do dai canh a = ");
    b = input("Nhap do dai canh b = ");
    tamgiacvuong(X0 , a, b);
end

function [] = tamgiacvuong(X0 , a , b)
    X = [X0(1,1) , X0(1,1) + a, X0(1,1) , X0(1, 1)];
    Y = [X0(1,2) , X0(1,2) , X0(1,2) + b , X0(1, 2)];
    plot(X , Y , 'r-');
    text(X(1), Y(1), 'A', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'right');
    text(X(2), Y(2), 'B', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'left');
    text(X(3), Y(3), 'C', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
end

