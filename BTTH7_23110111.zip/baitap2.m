function [] = baitap2()
    x = linspace(1,4);
    y = exp(x.^2);
    plot(x, y , 'b-.v');
    xlabel('Do thi ham e^x^2');
end