function [] = baitap8()
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    subplot(1 , 2 , 1);
    plot(x , exp(-x.^2));
    xlabel('Do thi ham so e^-x^2');
    subplot(1 , 2 , 2);
    plot3(x , y , exp(-(x.^2 + y.^2)));
    xlabel('Do thi ham so e^-(x^2 + y^2)');
end