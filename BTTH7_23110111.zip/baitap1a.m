function [] = baitap1a()
    plot((0:4));
    xlabel('Do thi ham x');
end