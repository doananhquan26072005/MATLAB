function [] = baitap6a()
    x = linspace(-4 , 2);
    y = abs(x.^2 + 3 * x);
    z = x.^3 - x - 2;
    subplot(1,2,1);
    plot(x , y);
    xlabel('Do thi ham abs(x^2 + 3x)');
    subplot(1,2,2);
    plot(x , z);
    xlabel('Do thi ham abs(x^3 - x - 2)');
end