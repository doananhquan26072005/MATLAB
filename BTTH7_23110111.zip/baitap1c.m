function [] = baitap1c()
    x = linspace(1,4);
    y = exp(x);
    plot(x, y);
    xlabel('Do thi ham e^x');
end