function [] = baitap11()
    X0 = input("Nhap toa do diem A theo kieu mang = ");
    r = input("Nhap ban kinh r = ");
    hinhtron(X0, r)
end

function [] = hinhtron(X0, r)
    theta = linspace(0 , 2*pi);
    x = X0(1 , 1) + r * cos(theta);
    y = X0(1 , 2) + r * sin(theta);
    plot(x,y,'b-');
end

