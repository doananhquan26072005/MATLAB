function [] = baitap7c()
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    plot3(x , y , exp(x) + y.^4 - x.^3 + 4*cos(pi*y));
    title('Do thi ham so e^x + y^4 - x^3 + 4cos(pi*y)');
end