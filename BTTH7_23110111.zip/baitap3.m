function [] = baitap3()
    x = linspace(-5,5);
    plot(x , x ./ (1 + x.^4) , 'r-.' ,'LineWidth',2 , 'Marker','o','MarkerEdgeColor','k' , 'MarkerSize',6 , 'MarkerFaceColor','b');
    xlabel('Do thi ham f(x)');
end