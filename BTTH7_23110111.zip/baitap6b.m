function [] = baitap6b()
    x = linspace(-2 , 4);
    y = x.^2;
    z = sqrt(x);
    subplot(2,1,1);
    plot(x , y);
    xlabel('Do thi ham x^2');
    subplot(2,1,2);
    plot(x , z);
    xlabel('Do thi ham sqrt(x)');
end