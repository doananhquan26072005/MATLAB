function [] = baitap7b()
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    plot3(x , y , sin(pi * x) + sin(pi * y) + sin(pi * x + pi * y));
    title("do thi ham sin(pi * x) + sin(pi * y) + sin(pi * x + pi * y)");
end