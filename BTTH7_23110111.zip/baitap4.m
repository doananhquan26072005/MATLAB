function [] = baitap4()
    x = linspace(0 , 2 * pi);
    y = sin(x);
    z = cos(x);
    t = tan(x);
    plot(x , y , 'r-' , x , z , 'b-' , x , t , 'g-');
    xlabel('x') 
    ylabel('y') 
    title('do thi ham sin , cos va tan') 
    legend ('sinx','cosx' , 'tanx')
end