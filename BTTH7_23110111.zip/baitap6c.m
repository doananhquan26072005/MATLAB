function [] = baitap6c()
    x = linspace(-10 , 10);
    f = exp(x);
    g = log(x);
    subplot(2,2,1);
    plot(x , f);
    xlabel('Do thi ham f(x) = e^x');
    subplot(2,2,2);
    plot(x , g);
    xlabel('Do thi ham g(x) = ln(x)');
    x = linspace(0 , 2 * pi);
    subplot(2,2,3);
    plot(x , sin(x));
    xlabel('Do thi ham sin(x)');
    subplot(2,2,4);
    plot(x , cos(x));
    xlabel('Do thi ham cos(x)');
end