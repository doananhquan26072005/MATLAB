function [] = baitap7a()
    x = linspace(-2 , 2);
    y = linspace(-2 , 2);
    plot3(x , y , 3 * x - x.^3 - 2*y.^2 + y.^4);
    title("do thi ham 3x - x^3 - 2y^2 + y^4");
end