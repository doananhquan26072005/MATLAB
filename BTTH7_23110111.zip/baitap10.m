function [] = baitap10()
    X0 = input("Nhap toa do diem A theo kieu mang = ");
    d = input("Nhap chieu dai d = ");
    r = input("Nhap chieu rong r = ");
    hinhchunhat(X0, d, r);
end

function [] = hinhchunhat(X0, d, r)
    X = [X0(1,1) , X0(1,1), X0(1,1) + r, X0(1, 1) + r , X0(1 , 1)];
    Y = [X0(1,2) , X0(1,2) + d, X0(1,2) + d, X0(1,2) , X0(1 , 2)];
    plot(X , Y , 'r-');
    text(X(1), Y(1), 'A', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'right');
    text(X(2), Y(2), 'B', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    text(X(3), Y(3), 'C', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
    text(X(4), Y(4), 'D', 'VerticalAlignment', 'top', 'HorizontalAlignment', 'left');
end

