function [] = baitap1d()
    x = linspace(1,4);
    y = exp(x.^2);
    plot(x, y);
    xlabel('Do thi ham e^x^2');
end