function [] = baitap1b()
    plot((1:4).^3);
    xlabel('Do thi ham x^3');
end