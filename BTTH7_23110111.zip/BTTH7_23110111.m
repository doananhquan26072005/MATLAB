%Ho va ten: Doan Anh Quan
%MSSV: 23110111
clear
close all
format long
%  baitap1a();
%  baitap1b();
%  baitap1c();
%  baitap2();
%  baitap3();
%  baitap4();
%  baitap5();
%  baitap6();
%  baitap7();
%  baitap8();
%  baitap9();
%  baitap10();
%  baitap11();